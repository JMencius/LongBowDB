from setuptools import setup, find_packages

setup(
    name='longbowdb',
    version='1.0',
    packages=find_packages(),
    include_package_data=True,
    package_data={
        'longbowdb': ['modules/*'],
    },
    install_requires=[],
    entry_points={
        'console_scripts': [
            'longbowdb=longbowdb.longbowdb:main',
        ],
    },
)