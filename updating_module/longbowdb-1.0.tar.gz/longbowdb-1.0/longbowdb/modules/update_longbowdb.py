#!/bin/env python3
import os
import json
import time
import psutil
import datetime
import logging
import pandas as pd
import subprocess

def add_monthly_cron_job(database):
    """
    Add a monthly cron job to update LongBowDB.

    Args:
    database: str, path to LongBowDB

    """
    try:
        flag_file = f"{database}/data/update.SUCCESS"
        cmd1 = f'rm -f {flag_file} && source "$(conda info --base)"/etc/profile.d/conda.sh && conda activate longbowdb && longbowdb -d {database} --update --check_idle > {database}/logs/update.log 2>&1'
        cmd2 = f'if [ ! -f \"{flag_file}\" ]; then source "$(conda info --base)"/etc/profile.d/conda.sh && conda activate longbowdb && longbowdb -d {database} --update --check_idle > {database}/logs/update.log 2>&1; fi'
        cron_job = f"0 0 1 * * {cmd1}\n 0 0 2-31 * * {cmd2}\n"

        result = subprocess.run(['crontab', '-l'], capture_output=True, text=True)
        if result.returncode == 0:
            existing_cron_jobs = result.stdout
        else:
            logging.error("Failed to get existing crontab jobs")
            return

        if cron_job in existing_cron_jobs:
            print("Job has already been added to crontab")
            return

        updated_cron_jobs = existing_cron_jobs + cron_job

        process = subprocess.run(['crontab', '-'], input=updated_cron_jobs, text=True)

        if process.returncode == 0:
            logging.info("Monthly job added successfully")
        else:
            logging.error("Failed to add job to crontab")

    except Exception as e:
        logging.error(f"{e}")
    

def check_server_status():
    """
    Check the server status

    Returns:
    True if the server is idle, otherwise False.

    """
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
    def get_cpu_info():
        cpu_percent = psutil.cpu_percent(interval=1)
        logical_cpus = psutil.cpu_count(logical=True)
        return cpu_percent, logical_cpus
    def get_memory_info():
        memory = psutil.virtual_memory()
        total_memory = memory.total / (1024 ** 3)  # GB
        used_memory_percent = memory.percent
        return total_memory, used_memory_percent
    def get_network_info():
        net_io_f = psutil.net_io_counters()
        time.sleep(3)
        net_io_r = psutil.net_io_counters()
        bytes_recv = (net_io_r.bytes_recv - net_io_f.bytes_recv) / (1024 ** 2)*3  # MB
        return bytes_recv
    
    CPU_THRESHOLD=80
    MEM_THRESHOLD=80
    DOWNLOAD_THRESHOLD=8

    cpu_percent, logical_cpus = get_cpu_info()
    logging.info(f"Used CPU percent: {cpu_percent}%")
    logging.info(f"CPU number: {logical_cpus}")
    
    total_memory, used_memory_percent = get_memory_info()
    logging.info(f"Total memory: {total_memory:.2f} GB")
    logging.info(f"Used memory percent: {used_memory_percent}%")
    
    bytes_recv = get_network_info()
    logging.info(f"Receiving: {bytes_recv:.2f} MB/s")

    if bytes_recv > DOWNLOAD_THRESHOLD or cpu_percent > CPU_THRESHOLD or used_memory_percent > MEM_THRESHOLD:
        return False
    else:
        return True

def update_metadata(database):
    """
    Update metadata of SRA runinfo table.

    Returns:
    List of appended run ids if the all steps run successfully, otherwise None.

    """
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
    DIR = database
    def backup():
        date = datetime.datetime.now().strftime("%Y%m%d")
        bkup = f"cp {DIR}/data/LongBowDB.csv {DIR}/bak/LongBowDB.{date}.csv && \
                 mv {DIR}/data/sra_runinfo_raw.txt {DIR}/bak/sra_runinfo_raw.{date}.txt"
        process = subprocess.Popen(bkup, shell=True)
        process.wait()
        return process.returncode
    def fetch_sra():
        esearch = f'{DIR}/bin/edirect/esearch -db sra -query "Homo sapiens [Organism] AND Oxford Nanopore [Platform] AND dna data [Filter]" | {DIR}/bin/edirect/efetch -format runinfo > {DIR}/data/sra_runinfo_raw.txt'
        process = subprocess.Popen(esearch, shell=True)
        process.wait()
        return process.returncode
    def update_table():
        df_raw = pd.read_csv(f'{DIR}/data/LongBowDB.csv', header=0, index_col=None)
        df_new = pd.read_csv(f'{DIR}/data/sra_runinfo_raw.txt', header=0 ,index_col=None)
        extend_run = list(set(df_new['Run']) - set(df_raw['Run']))
        for col in df_raw.columns:
            if col not in df_new.columns:
                df_new[col] = pd.NA
        df_new = df_new[df_raw.columns]
        df_extend = df_new[df_new['Run'].isin(extend_run)]
        df_updated = pd.concat([df_raw, df_extend], ignore_index=True)
        df_updated.to_csv(f'{DIR}/data/LongBowDB.csv', index=False, header=True)
        return extend_run
    
    if backup() == 0:
        if fetch_sra() == 0:
            return update_table()
        else:
            return None
    else:
        return None

def runlongbow(extend_run, database, generate_ext=True):
    """
    Download appended SRA runs and apply longbow.

    Args:
    extend_run: list[str], appended SRA run ids
    database: str, path to LongBowDB

    """
    DIR = database
    lbversion = subprocess.run(f'longbow --version', shell=True, stdout=subprocess.PIPE).stdout.decode('utf-8').strip().split(' ')[2]
    # Download and run longbow
    target_dir = f"{DIR}/data/sra"
    if not os.path.exists(target_dir):
        os.makedirs(target_dir)
    df = pd.read_csv(f'{DIR}/data/LongBowDB.csv', header=0, index_col=None)
    count = 1
    for runid in extend_run:
        logging.info(f"Downloading and running LongBow for {runid} ......{count}/{len(extend_run)}")
        cmd = f'{DIR}/bin/sratoolkit/bin/fastq-dump {runid} -N 1 -X 10000 -O {target_dir}'
        subprocess.run(cmd, shell=True)
        if os.path.exists(f"{target_dir}/{runid}.fastq"):
            cmd = f'longbow -i {target_dir}/{runid}.fastq -o {target_dir}/{runid}.json'
            subprocess.run(cmd, shell=True)
            if not os.path.exists(f"{target_dir}/{runid}.json"):
                df.loc[df['Run'] == runid, 'Prediction'] = pd.NA
                df.loc[df['Run'] == runid, 'Note'] = "RUN_FAIL"
                df.loc[df['Run'] == runid, 'Confidence_Level'] = '-'
            else:
                with open(f"{target_dir}/{runid}.json") as json_file:
                    data = json.load(json_file)
                    flowcell = data.get("Flowcell", "UNKNOWN")
                    software = data.get("Software", "UNKNOWN")
                    version = data.get("Version", "UNKNOWN")
                    mode = data.get("Mode", "UNKNOWN")
                    conf = data.get("Confidence level", "-")
                    combined_value = f"{flowcell}-{software}-{version}-{mode}"
                    if 'UNKNOWN' in combined_value:
                        df.loc[df['Run'] == runid, 'Prediction'] = pd.NA
                        df.loc[df['Run'] == runid, 'Note'] = "RUN_FAIL"
                        df.loc[df['Run'] == runid, 'Confidence_Level'] = '-'
                    else:
                        df.loc[df['Run'] == runid, 'Prediction'] = combined_value
                        df.loc[df['Run'] == runid, 'Note'] = pd.NA
                        df.loc[df['Run'] == runid, 'Confidence_Level'] = conf
        else:
            df.loc[df['Run'] == runid, 'Prediction'] = pd.NA
            df.loc[df['Run'] == runid, 'Note'] = "DOWNLOAD_FAIL"
            df.loc[df['Run'] == runid, 'Confidence_Level'] = '-'
        count += 1
        logging.info(f"{runid} updated.")
    if generate_ext:
        df_ext = df[df['Run'].isin(extend_run)]
        df_ext.to_csv(f'{DIR}/data/LongBowDB_ext.csv', index=False, header=True)
    df.to_csv(f'{DIR}/data/LongBowDB.csv', index=False, header=True)
    cmd = f'rm -f {target_dir}/*.fastq'
    subprocess.run(cmd, shell=True)

    return lbversion

def make_json(database, lbversion, update_time):
    """
    Make longbowdb.json file for the website display.

    Args:
    database: str, path to LongBowDB
    lbversion: str, LongBow version
    update_time: str, update time

    """
    DIR = database

    # Record the prediction and reasons for each SRA
    df = pd.read_csv(f'{DIR}/data/LongBowDB.csv', header=0, index_col=None)
    info = {}
    info['database_info'] = {'upto': update_time, 'lb_version': lbversion}
    for row, data in df.iterrows():
        sra = data['Run']
        if pd.isna(data['Prediction']):
            info[sra] = {'pred': 'Failed',
                         'note': 'Failed',
                         'conf': '-'}
        else:
            info[sra] = {'pred': data['Prediction'].replace('guppy', 'Guppy').replace('dorado', 'Dorado').replace('3or4', '3 or 4').replace('5or6', '5 or 6'),
                         'note': 'Passed',
                         'conf': data['Confidence_Level']}
        if pd.notna(data['Note']):
            info[sra]['note'] = data['Note']
    
    with open(f"{DIR}/data/longbowdb.json", "w") as json_file:
        json.dump(info, json_file, indent=4)

    logging.info("longbowdb.json updated.")
    return True

def update_longbowdb(database, check_idle=True, test=False):
    """
    Main function to update LongBowDB.

    Args:
    database: str, path to LongBowDB
    check_idle: bool, whether to check the server status
    test: bool, only test if sratoolkit and longbow could be run successfully

    """
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
    if test:
        lbversion = runlongbow(['SRR31592210'], database, generate_ext=False)
        logging.info(f"LongBow version: {lbversion}")
        logging.info(f'Test finished. Please check result at {database}/data/sra/SRR31592210.json')
        exit(0)

    # Check if the current server is idle
    check_status = check_server_status() if check_idle else True 
    if not check_status:
        logging.info("Server is busy, delay the task.")
        exit(0)

    # Run the updating process
    logging.info("Server is idle, start updating...")
    logging.info("Start updating sra runinfo...")
    update_time = datetime.datetime.now().strftime("%Y-%m-%d")
    extend_run = update_metadata(database)
    if extend_run is None:
        logging.warning("\033[91mBackup or fetch SRA failed, please check.\033[0m")
        exit(1)
    elif extend_run == []:
        logging.info("No appended SRA data found, updating finished.")
        exit(0)

    logging.info("Start downloading and running LongBow...")
    lbversion = runlongbow(extend_run, database)
    logging.info("LongBowDB updated.")
    if make_json(database, lbversion, update_time):
        with open(f"{database}/data/update.SUCCESS", "w") as success_file:
            success_file.write(f"LongBowDB updating at {update_time}")
        logging.info("Completed.")
    else:
        logging.warning("\033[91mFailed while running longbow or making json, please check\033[0m")
        exit(1)
