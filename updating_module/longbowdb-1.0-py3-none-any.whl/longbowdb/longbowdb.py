#!/bin/env python3
import argparse
import logging
from longbowdb import __version__
from longbowdb.modules import update_longbowdb

def get_args():
    parser = argparse.ArgumentParser(
        description="For LongBowDB updating",
        usage="%(prog)s -d path_to_longbowdb --update")
    
    parser = argparse.ArgumentParser(description="LongbowDB update script")
    parser.add_argument('-v', '--version', action='version', version=f'%(prog)s {__version__}')
    parser.add_argument('-d', '--db', required=True, help='Path to the longbowdb')
    parser.add_argument('--test', default=False, action='store_true', help='Test download and run longbow with one run')
    parser.add_argument('--update', default=False, action='store_true', help='Update the database')
    parser.add_argument('--check_idle', default=False, action='store_true', help='Update the database')
    parser.add_argument('--schedule', default=False, action='store_true', help='Schedule the update')
    return parser.parse_args()

def main():
    args = get_args()
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
    if args.update:
        logging.info("Start updating LongBowDB")
        logging.info(f"Database path: {args.db}")
        update_longbowdb.update_longbowdb(args.db, check_idle=args.check_idle)
        logging.info(f"Update finished.\nPlease check the extended table at {args.db}/data/LongBowDB_ext.csv\n and release longbowdb.json on github.")
        exit(0)
    if args.test:
        logging.info("Start testing LongBowDB")
        logging.info(f"Database path: {args.db}")
        update_longbowdb.update_longbowdb(args.db, test=args.test)
        exit(0)
    if args.schedule:
        logging.info("Start adding monthly updating job to crontab")
        logging.info(f"Database path: {args.db}")
        update_longbowdb.add_monthly_cron_job(args.db)
        exit(0)



if __name__ == "__main__":
    main()